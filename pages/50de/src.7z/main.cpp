#include "time.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <pthread.h>
#include "../lvgl/lvgl.h"
#include "lv_freetype.h"
#include "serial/serial.h"
#include "logo.h"
//#include <libconfig.h>
#include <atlstr.h>
#include <libconfig.h++>

using namespace std;
using namespace libconfig;
using namespace serial;
using std::exception;

char ports[512];
Serial mserial;
static char port_com[32] = { "COM1" };
static lv_ft_info_t ft_font;
static lv_obj_t* btn_connect;
static lv_obj_t* btn_clear;
static lv_obj_t* ta;
extern void list_ports(char* ports);
char lang[32];
#define FUN_BTN_LEN 19
typedef struct
{
    string label_connect;
    string label_disconnect;
    string label_clear;
    string label_port;
    string label_btn[FUN_BTN_LEN];
    string font;
    string tips_1;
}lang_cfg_t;
//初始语言
lang_cfg_t  lang_cfg = {
    "点击连接",
    "点击断开",
    "清空",
    "通信端口",
    {"电源打开","电源关闭","输出打开","输出关闭","平衡输入","耳机输入","RCA 输入","混合输入","信号触发","音量最大","音量增加","音量中间","音量减小","音量最小","功放静音","音量状态","电源状态","系统版本","  恢复设置到出厂状态  "} ,
    "C:/WINDOWS/FONTS/simkai.ttf"
};
static void event_handler(lv_event_t* e)
{
    lv_event_code_t code = lv_event_get_code(e);
    lv_obj_t* obj = lv_event_get_target(e);
    if(code == LV_EVENT_VALUE_CHANGED) {
        char buf[32];
        lv_roller_get_selected_str(obj, buf, sizeof(buf));
        LV_LOG_USER("Selected value: %s", buf);
    }
}
static void dropdown_com_event_handler(lv_event_t* e)
{
    lv_event_code_t code = lv_event_get_code(e);
    lv_obj_t* obj = lv_event_get_target(e);
    if(code == LV_EVENT_VALUE_CHANGED) {
        char buf[64];
        lv_dropdown_get_selected_str(obj, buf, sizeof(buf));
        char* str = strchr(buf, ',');
        *str = '\0';
        strcpy(port_com, buf);
        lv_dropdown_set_text(obj, port_com);
        if(mserial.isOpen( ))
        {
            mserial.close( );
            lv_label_set_text(lv_obj_get_child(btn_connect, 0), lang_cfg.label_connect.c_str( ));
        }
        LV_LOG_USER("Option: %s", buf);
    }
}
static void btn_connect_event_handler(lv_event_t* e)
{
    lv_event_code_t code = lv_event_get_code(e);
    lv_obj_t* obj = lv_event_get_target(e);
    int32_t   index = (int32_t)lv_event_get_user_data(e);
    if(code == LV_EVENT_CLICKED) {
        LV_LOG_USER("Clicked");
        if(mserial.isOpen( ))
        {
            mserial.close( );
            lv_label_set_text(lv_obj_get_child(btn_connect, 0), lang_cfg.label_connect.c_str( ));
            return;
        }
        //Serial my_serial(port_com, 115200, Timeout::simpleTimeout(1000));
        mserial.setPort(port_com);
        mserial.setBaudrate(9600);
        mserial.setTimeout(Timeout::max( ), 500, 0, 500, 0);
        mserial.setStopbits(stopbits_one);
        mserial.setParity(parity_none);
        mserial.setBytesize(eightbits);
        mserial.open( );
        if(mserial.isOpen( ))
        {
            lv_label_set_text(lv_obj_get_child(obj, 0), lang_cfg.label_disconnect.c_str( ));
        }
        else {
            LV_LOG_USER("打开%s失败\n", port_com);

        }
    }

}
static void btn_event_handler(lv_event_t* e)
{
    lv_event_code_t code = lv_event_get_code(e);
    lv_obj_t* obj = lv_event_get_target(e);
    int32_t   index = (int32_t)lv_event_get_user_data(e);
    if(code == LV_EVENT_CLICKED) {
        LV_LOG_USER("id:%d Clicked", index);
        if(mserial.isOpen( ) || index >= 255)
        {
            switch(index)
            {
                case 0:mserial.write("System_Power=ON\r\n");break;
                case 1:mserial.write("System_Power=OFF\r\n");break;
                case 2:mserial.write("Output_Mute=Output:Speaker:1,ON\r\n");break;
                case 3:mserial.write("Output_Mute=Output:Speaker:1,OFF\r\n");break;
                case 4:mserial.write("Switch_Audio=Input:Line:1,Output:Speaker:1\r\n");break;
                case 5:mserial.write("Switch_Audio=Input:Line:2,Output:Speaker:1\r\n");break;
                case 6:mserial.write("Switch_Audio=Input:Line:3,Output:Speaker:1\r\n");break;
                case 7:mserial.write("Switch_Audio=Input:Sum:1,Output:Speaker:1\r\n");break;
                case 8:mserial.write("System_Power=Auto\r\n");break;
                case 9:mserial.write("Output_Volume=Output:Speaker:1,100\r\n");break;
                case 10:mserial.write("Output_Volume=Output:Speaker:1,+\r\n");break;
                case 11:mserial.write("Output_Volume=Output:Speaker:1,50\r\n");break;
                case 12:mserial.write("Output_Volume=Output:Speaker:1,-\r\n");break;
                case 13:mserial.write("Output_Volume=Output:Speaker:1,0\r\n");break;
                case 14:mserial.write("Output_Mute=Output:Speaker:1,OFF\r\n");break;
                case 15:mserial.write("Status=Volume:Speaker:1\r\n");break;
                case 16:mserial.write("Status=Power\r\n");break;
                case 17:mserial.write("Status=Firmware,System\r\n");break;
                case 18:mserial.write("SonSSIP_FactoryReset\r\n");break;
                case 255:lv_textarea_set_text(ta, "");break;
                default:break;
            }

        }
        else {
            //LV_LOG_USER("%s没有打开!\n", port_com);


            lv_obj_t* mbox1 = lv_msgbox_create(NULL, "", lang_cfg.tips_1.c_str( ), NULL, true);
            //lv_obj_add_event_cb(mbox1, event_cb, LV_EVENT_VALUE_CHANGED, NULL);
            lv_msgbox_t* mbox = (lv_msgbox_t*)mbox1;
            lv_obj_set_style_text_font(lv_obj_get_child(mbox->content, 0), ft_font.font, 0);
            lv_obj_center(mbox1);
        }

    }

}
//读取配置文件
int read_config(const char* file)
{
    Config cfg;

    // Read the file. If there is an error, report it and exit.
    try
    {
        cfg.readFile(file);
    }
    catch(const FileIOException& fioex)
    {
        LV_LOG_USER("I/O error while reading file.");
        return(EXIT_FAILURE);
    }
    catch(const ParseException& pex)
    {
        LV_LOG_USER("Parse error at %s:d - %s", pex.getFile( ), pex.getLine( ), pex.getError( ));
        return(EXIT_FAILURE);
    }

    //// Get the store name.
    try
    {
        string name = cfg.lookup("lang");
        string font = cfg.lookup("font");
        LV_LOG_USER("lang: %s", name.c_str( ));
        strcpy(lang, name.c_str( ));
        lang_cfg.font = font;
    }
    catch(const SettingNotFoundException& nfex)
    {
        LV_LOG_USER("No 'lang' setting in configuration file.");
    }
    const Setting& root = cfg.getRoot( );

    // Output a list of all books in the inventory.
    try
    {

        const Setting& lang_list = root.lookup(lang);

        lang_cfg.label_clear = lang_list["label_clear"].c_str( );
        lang_cfg.label_connect = lang_list["label_connect"].c_str( );
        lang_cfg.label_disconnect = lang_list["label_disconnect"].c_str( );
        lang_cfg.label_port = lang_list["label_port"].c_str( );
        lang_cfg.tips_1 = lang_list["tips_1"].c_str( );
        int count = lang_list["label_btn"].getLength( );
        for(int i = 0; i < count; ++i)
        {

            lang_cfg.label_btn[i] = lang_list["label_btn"][i].c_str( );
            //LV_LOG_USER("%s", lang_cfg.label_btn[i].c_str( ));
        }

    }
    catch(const SettingNotFoundException& nfex)
    {
        // Ignore.
    }
    return (EXIT_SUCCESS);
}
// 串口接收线程
void* sp_receive_fun(void* arg)
{
    while(1)
    {
        try {
            if(mserial.available( ))
            {
                lv_textarea_set_cursor_pos(ta, LV_TEXTAREA_CURSOR_LAST);
                lv_textarea_add_text(ta, mserial.readline( ).c_str( ));
                mserial.flushInput( );
            }
        }
        catch(IOException e)
        {

        }

        Sleep(1);

    }
    return 0;
}
static void textarea_event_handler(lv_event_t* e)
{
    lv_obj_t* ta = lv_event_get_target(e);
    LV_LOG_USER("Enter was pressed. The current text is: %s", lv_textarea_get_text(ta));
}
lv_obj_t* create_main_page(lv_obj_t* parent)
{

    read_config("./tsc.conf");

    list_ports(ports);
    time_t  t_sec;
    time(&t_sec);
    struct tm* local_time = localtime(&t_sec);
    ft_font.name = lang_cfg.font.c_str( );
    //ft_font.name = "yayuan.ttf";
    ft_font.weight = 16;
    ft_font.style = FT_FONT_STYLE_NORMAL;
    lv_ft_font_init(&ft_font);

    lv_obj_t* cont = lv_obj_create(parent);
    lv_obj_remove_style_all(cont);
    lv_obj_t* bg = lv_img_create(cont);
    //lv_img_set_src(bg, "/data/images/bg1.png");
    lv_obj_set_size(cont, LV_HOR_RES, LV_VER_RES);

    lv_obj_t* label_port = lv_label_create(cont);
    lv_obj_set_style_text_font(label_port, ft_font.font, 0);
    lv_obj_set_style_text_color(label_port, lv_color_black( ), 0);
    lv_label_set_text(label_port, lang_cfg.label_port.c_str( ));
    lv_obj_align_to(label_port, cont, LV_ALIGN_TOP_LEFT, 20, 20);

    lv_obj_t* dropdown_com = lv_dropdown_create(cont);
    lv_dropdown_set_options(dropdown_com, ports);
    lv_obj_set_style_pad_all(dropdown_com, 6, 0);
    lv_obj_align_to(dropdown_com, label_port, LV_ALIGN_OUT_RIGHT_MID, 20, 0);
    lv_obj_add_event_cb(dropdown_com, dropdown_com_event_handler, LV_EVENT_ALL, NULL);

    lv_obj_t* dropdown_com_list = lv_dropdown_get_list(dropdown_com);
    lv_obj_set_style_pad_all(dropdown_com_list, 6, 0);
    lv_obj_set_style_text_font(dropdown_com_list, ft_font.font, 0);
    lv_obj_set_style_pad_all(dropdown_com_list, 6, 0);
    lv_dropdown_set_text(dropdown_com, port_com);

    btn_connect = lv_btn_create(cont);
    lv_obj_set_style_pad_top(btn_connect, 6, 0);
    lv_obj_set_style_pad_bottom(btn_connect, 6, 0);
    lv_obj_add_event_cb(btn_connect, btn_connect_event_handler, LV_EVENT_ALL, NULL);
    lv_obj_align_to(btn_connect, dropdown_com, LV_ALIGN_OUT_RIGHT_MID, 20, -10);

    lv_obj_t* label_btn = lv_label_create(btn_connect);
    lv_label_set_text(label_btn, lang_cfg.label_connect.c_str( ));
    lv_obj_set_style_text_font(label_btn, ft_font.font, 0);
    lv_obj_set_style_text_color(label_btn, lv_color_black( ), 0);
    lv_obj_center(label_btn);

    lv_obj_t* cont2 = lv_obj_create(cont);
    lv_obj_remove_style_all(cont2);
    lv_obj_set_size(cont2, 220, LV_VER_RES - 80);
    // lv_obj_set_style_bg_opa(cont, LV_PCT(100), 0);
    // lv_obj_set_style_bg_color(cont, lv_color_hex(0x005500), 0);
    //lv_obj_set_style_pad_all(cont2, 6, 6);
    lv_obj_align_to(cont2, parent, LV_ALIGN_RIGHT_MID, -10, 20);
    //lv_obj_set_style_border_width(cont2, 1, 0);
    lv_obj_set_flex_flow(cont2, LV_FLEX_FLOW_ROW_WRAP);
    lv_obj_set_flex_align(cont2, LV_FLEX_ALIGN_SPACE_AROUND, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_SPACE_AROUND);

    lv_obj_t* btn;
    lv_obj_t* label;
    //ft_font.style = FT_FONT_STYLE_BOLD;
    //lv_ft_font_init(&ft_font);

    const lv_palette_t btn_color[FUN_BTN_LEN] = { LV_PALETTE_BLUE, LV_PALETTE_BLUE, LV_PALETTE_BLUE, LV_PALETTE_BLUE, LV_PALETTE_GREEN,LV_PALETTE_GREEN,LV_PALETTE_GREEN,LV_PALETTE_GREEN,LV_PALETTE_GREEN,  LV_PALETTE_ORANGE, LV_PALETTE_ORANGE, LV_PALETTE_ORANGE, LV_PALETTE_ORANGE,
                          LV_PALETTE_ORANGE,  LV_PALETTE_RED,LV_PALETTE_PURPLE,LV_PALETTE_PURPLE,LV_PALETTE_PURPLE, LV_PALETTE_TEAL };
    for(int32_t i = 0;i < FUN_BTN_LEN;i++)
    {
        btn = lv_btn_create(cont2);
        lv_obj_set_style_pad_top(btn, 6, 0);
        lv_obj_set_style_pad_bottom(btn, 6, 0);
        if(i != FUN_BTN_LEN - 1)lv_obj_set_width(btn, 100);
        lv_obj_set_style_bg_color(btn, lv_palette_main(btn_color[i]), 0);
        lv_obj_add_event_cb(btn, btn_event_handler, LV_EVENT_ALL, (void*)i);
        lv_obj_align_to(btn, btn_connect, LV_ALIGN_OUT_BOTTOM_MID, 0, 50);

        label = lv_label_create(btn);
        lv_label_set_text_fmt(label, "%s", lang_cfg.label_btn[i].c_str( ));
        lv_obj_set_style_text_font(label, ft_font.font, 0);
        lv_obj_set_style_text_color(label, lv_color_black( ), 0);
        //lv_obj_set_style_text_color(label, lv_color_black( ), 0);
        lv_obj_center(label);
    }



    lv_obj_t* img = lv_img_create(cont);
    lv_img_set_src(img, "/logo.png");
    // 256 就是1倍
    lv_img_set_zoom(img, 100);
    //抗锯齿
    lv_img_set_antialias(img, true);
    // 0背景透明 255默认白色
    lv_obj_set_style_bg_opa(img, 0, 0);
    //设置图像尺寸模式,返回缩放后的大小
    lv_img_set_size_mode(img, LV_IMG_SIZE_MODE_REAL);
    //lv_obj_set_style_border_width(img, 1, 0);
    lv_obj_set_size(img, LV_SIZE_CONTENT, LV_SIZE_CONTENT);
    lv_obj_align_to(img, cont2, LV_ALIGN_OUT_TOP_MID, 0, 10);


    ta = lv_textarea_create(cont);
    //lv_textarea_set_one_line(ta, true);
    //lv_obj_add_state(ta, LV_STATE_DISABLED);
    //lv_obj_clear_state(ta, LV_STATE_EDITED);
    lv_obj_set_size(ta, LV_HOR_RES - lv_obj_get_width(cont2) - 40, LV_VER_RES - 80);
    lv_obj_align(ta, LV_ALIGN_LEFT_MID, 10, 20);
    lv_obj_set_style_border_width(ta, 1, 0);
    lv_obj_set_style_border_color(ta, lv_color_hex(0x7A3CB7), 0);
    lv_obj_add_event_cb(ta, textarea_event_handler, LV_EVENT_READY, ta);

    btn_clear = lv_btn_create(cont);
    lv_obj_set_style_pad_top(btn_clear, 6, 0);
    lv_obj_set_style_pad_bottom(btn_clear, 6, 0);
    lv_obj_add_event_cb(btn_clear, btn_event_handler, LV_EVENT_ALL, (void*)255);
    lv_obj_align_to(btn_clear, btn_connect, LV_ALIGN_OUT_RIGHT_TOP, 110, 0);

    label = lv_label_create(btn_clear);
    lv_label_set_text(label, lang_cfg.label_clear.c_str( ));
    lv_obj_set_style_text_font(label, ft_font.font, 0);
    lv_obj_set_style_text_color(label, lv_color_black( ), 0);
    lv_obj_center(label);

    label = lv_label_create(cont);
    lv_label_set_text(label, "Sonavox shuzou. All rights reserved. \tSupport By:87000013");
    lv_obj_set_style_text_font(label, ft_font.font, 0);
    lv_obj_set_style_text_color(label, lv_color_hex(0x00A3CD), 0);
    lv_obj_align_to(label, cont, LV_ALIGN_BOTTOM_LEFT, 10, -2);

    pthread_t tid1;
    int ret = pthread_create(&tid1, NULL, sp_receive_fun, NULL);
    if(ret != 0)
    {
        perror("pthread_create failed\n");

    }

    return cont;
}

