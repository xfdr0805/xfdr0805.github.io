﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NPOI.SS.UserModel;
using NPOI.SS.Util;
using NPOI.XSSF.UserModel;
using NPOI.HSSF.UserModel;
using System.IO;

namespace GerberView
{
    public partial class Form2 : Form
    {
        XSSFWorkbook workBook;
        List<Placement> pst;//顶层坐标
        List<Placement> psb;//底层坐标
        //通过委托调用父窗体函数
        public delegate void reload_layer(int index);
        public event reload_layer reload_event;
        public Form2()
        {
            InitializeComponent();
            dataGridView1.ContextMenuStrip = contextMenuStrip1;
        }

        private void btn_bom_Click(object sender, EventArgs e)
        {
            openFileDialog_bom.Filter = "2007 Excel文档|*.xlsx";
            openFileDialog_bom.Multiselect = false;
            DialogResult result = openFileDialog_bom.ShowDialog();
            if (result == DialogResult.OK)
            {
                tbx_bom.Text = openFileDialog_bom.FileName;
                this.Text = openFileDialog_bom.FileName;
            }
            if (tbx_bom.Text == "")
            {
                MessageBox.Show("请选择正确的BOM");
                return;
            }
            Console.WriteLine(tbx_bom.Text);
            workBook = new XSSFWorkbook(tbx_bom.Text);
            ISheet sheet = workBook.GetSheetAt(0);//"PCB 部分"
            //计算总行数
            int lastNum = sheet.LastRowNum;
            Console.WriteLine("总行数:" + lastNum);
            //从第1行开始
            //Console.WriteLine(sheet.GetRow(3).GetCell(1).StringCellValue);
            dataGridView1.Rows.Clear();
            for (int i = 2; i < lastNum; i++)
            {
                if (sheet.GetRow(i) != null)
                {
                    //Console.WriteLine(i + " ---> " + sheet.GetRow(i).Count());
                    dataGridView1.Rows.Add();
                    for (int j = 0; j < 10; j++)
                    {
                        if (sheet.GetRow(i).GetCell(j) != null)
                        {
                            if (sheet.GetRow(i).Cells.Count > 10)
                            {
                                //dataGridView1.Rows[i].Cells[j].Value = sheet.GetRow(i).GetCell(j).StringCellValue;
                                switch (sheet.GetRow(i).GetCell(j).CellType)
                                {
                                    case CellType.Numeric:
                                        //Console.WriteLine(j + " ---> " + sheet.GetRow(i).GetCell(j).NumericCellValue);
                                        dataGridView1.Rows[i - 2].Cells[j].Value = sheet.GetRow(i).GetCell(j).NumericCellValue;
                                        break;
                                    case CellType.String:
                                        //Console.WriteLine(j + " ---> " + sheet.GetRow(i).GetCell(j).StringCellValue);
                                        dataGridView1.Rows[i - 2].Cells[j].Value = sheet.GetRow(i).GetCell(j).StringCellValue;

                                        break;

                                }

                            }
                            else
                            {
                                Console.WriteLine(i + " ---> cells < 10");
                            }

                        }

                    }
                }


            }
            //dataGridView1.AutoResizeColumns();
            dataGridView1.AutoResizeRows();
        }

        private void btn_rep_Click(object sender, EventArgs e)
        {
            openFileDialog_rep.Filter = "Placement 坐标文件|*.rep";
            openFileDialog_rep.Multiselect = false;
            DialogResult result = openFileDialog_rep.ShowDialog();
            if (result == DialogResult.OK)
            {
                tbx_rep.Text = openFileDialog_rep.FileName;
            }
            if (tbx_rep.Text == "")
            {
                MessageBox.Show("请选择正确的坐标文件");
                return;
            }
            string temp = null;
            int line = 0;
            StreamReader sr = File.OpenText(tbx_rep.Text);
            pst = new List<Placement>();
            while ((temp = sr.ReadLine()) != null)
            {

                if (temp.Contains("Total Number of SMD Components on Top"))
                {
                    string s = temp.Remove(0, temp.IndexOf(':') + 1);
                    line = int.Parse(s);
                    sr.ReadLine();//空一行
                    sr.ReadLine();//空一行
                    for (int i = 0; i < line; i++)
                    {

                        temp = sr.ReadLine();
                        //坐标文件格式 座位号 X Y 长度都为10 角度为7

                        string str = temp.Substring(0, 10).Trim();
                        string x = temp.Substring(10, 10).Trim();
                        string y = temp.Substring(20, 10).Trim();
                        string r = temp.Substring(30, 7).Trim();
                        if (i == 0)
                        {
                            label_first_smd.Text = string.Format("{0}--->X:{1} Y:{2}", str, x, y);
                        }
                        Placement p = new Placement();
                        p.Symbol = str;
                        p.X_pos = x;
                        p.Y_pos = y;
                        p.Rotation = r;
                        pst.Add(p);
                    }
                }
            }
            sr.Close();
            sr = File.OpenText(tbx_rep.Text);
            psb = new List<Placement>();
            while ((temp = sr.ReadLine()) != null)
            {

                if (temp.Contains("Total Number of SMD Components on Bottom"))
                {
                    string s = temp.Remove(0, temp.IndexOf(':') + 1);
                    line = int.Parse(s);
                    sr.ReadLine();//空一行
                    sr.ReadLine();//空一行
                    for (int i = 0; i < line; i++)
                    {

                        temp = sr.ReadLine();
                        //坐标文件格式 座位号 X Y 长度都为10 角度为7

                        string str = temp.Substring(0, 10).Trim();
                        string x = temp.Substring(10, 10).Trim();
                        string y = temp.Substring(20, 10).Trim();
                        string r = temp.Substring(30, 7).Trim();
                        Placement p = new Placement();
                        p.Symbol = str;
                        p.X_pos = x;
                        p.Y_pos = y;
                        p.Rotation = r;
                        psb.Add(p);
                    }
                }
            }
            Btn_Pos.Enabled = true;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.Rows.Count <= 1) { return; }
            //获取座位号
            Console.WriteLine(dataGridView1.Rows[e.RowIndex].Cells[7].Value);
            string location = (string)dataGridView1.Rows[e.RowIndex].Cells[7].Value;
            string[] loc;
            StringBuilder sb = new StringBuilder();
            sb.Append("G04 Sonavox auto mark smd commpent helper *\r\n");
            sb.Append("G04 Draw by:101367 *\n");
            sb.Append("%MOIN*%\n");//单位选择
            sb.Append("%FSLAX55Y55*%\n");//坐标系选择
            //sb.Append("%ADD12R,0.050X0.050X*%\n");//画圆点
            sb.Append(string.Format("%ADD11C,{0}*%\n", numericUpDown_size.Value.ToString()));//画圆点
            sb.Append("\nG54D11*\n");//选择自定义光圈
            if (location != "")
            {
                loc = location.Split(',');
                bool find = false;
                foreach (string s in loc)
                {
                    find = false;
                    foreach (Placement p in pst)
                    {

                        if (s == p.Symbol)
                        {
                            find = true;
                            Int32 xpos = Int32.Parse(p.X_pos) + (Int32)numericUpDown_x.Value;
                            Int32 ypos = Int32.Parse(p.Y_pos) + (Int32)numericUpDown_y.Value;
                            xpos = xpos * 100;
                            ypos = ypos * 100;
                            sb.Append(string.Format("X{0}Y{1}D03*\n", xpos, ypos));//标识位置
                            //if (p.X_pos.Contains('.'))
                            //{

                            //    sb.Append(string.Format("X{0}Y{1}D03*\n", xpos, ypos));//标识位置

                            //}
                            //else
                            //{
                            //    sb.Append(string.Format("X{0}Y{1}D03*\n", p.X_pos + "00", p.Y_pos + "00"));//标识位置

                            //}
                            Console.WriteLine(string.Format("Top SMD:{0}--->X:{1} Y:{2} R:{3}", s, p.X_pos, p.Y_pos, p.Rotation));
                            //break;
                            continue;//跳过剩下的代码，继续执行循环
                        }

                    }
                    if (find == false)
                    {
                        foreach (Placement p in psb)
                        {
                            if (s == p.Symbol)
                            {
                                find = true;
                                Int32 xpos = Int32.Parse(p.X_pos) + (Int32)numericUpDown_x.Value;
                                Int32 ypos = Int32.Parse(p.Y_pos) + (Int32)numericUpDown_y.Value;
                                xpos = xpos * 100;
                                ypos = ypos * 100;
                                sb.Append(string.Format("X{0,0.00}Y{1,0.00}D03*\n", xpos, ypos));//标识位置
                                //if (p.X_pos.Contains('.'))
                                //{
                                //    sb.Append(string.Format("X{0}Y{1}D03*\n", p.X_pos.Remove('.'), p.Y_pos.Remove('.')));//标识位置

                                //}
                                //else
                                //{
                                //    sb.Append(string.Format("X{0}Y{1}D03*\n", p.X_pos + "00", p.Y_pos + "00"));//标识位置

                                //}
                                Console.WriteLine(string.Format("Bottom SMD:{0}--->X:{1} Y:{2} R:{3}", s, p.X_pos, p.Y_pos, p.Rotation));
                                continue;//跳过剩下的代码，继续执行循环
                            }

                        }
                    }

                    if (find == false)
                    {
                        MessageBox.Show(s + "的坐标未找到，请确认！！！\r\n可能是座位号不正确或者在MI部分");
                        return;
                    }
                }
                sb.Append("M02*\n");
                richTextBox1.Text = sb.ToString();
                //保存到文件，使用gerberV加载，reload即可刷新视图
                StreamWriter sw = new StreamWriter(@"Auto-Generate-Gerber.gbx");
                sw.Write(sb.ToString());
                sw.Flush();
                sw.Close();
                reload_event(0);
            }

        }

        private void Btn_Pos_Click(object sender, EventArgs e)
        {
            numericUpDown_x.Value = numericUpDown_pos_x.Value - Int32.Parse(pst[0].X_pos);
            numericUpDown_y.Value = numericUpDown_pos_y.Value - Int32.Parse(pst[0].Y_pos);
        }


        private void makedAsPlatedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                dataGridView1.SelectedRows[0].DefaultCellStyle.BackColor = Color.Green;
            }
            dataGridView1.ClearSelection();
            dataGridView1.Update();
        }

        private void cancelPlatedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                dataGridView1.SelectedRows[0].DefaultCellStyle.BackColor = DefaultBackColor;
            }
            dataGridView1.ClearSelection();
            dataGridView1.Update();
        }

        private void dataGridView1_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {

            if (e.Button == MouseButtons.Right)
            {

                if (e.RowIndex >= 0)
                {
                    dataGridView1.ClearSelection();
                    dataGridView1.Rows[e.RowIndex].Selected = true;
                    contextMenuStrip1.Show(MousePosition.X, MousePosition.Y);
                }



            }
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Sonavox auto mark smd commpent helper *\r\n");
            sb.Append("Draw by:101367 *\n");
            sb.Append("%MOIN*%\n");//单位选择
            sb.Append("%FSLAX55Y55*%\n");//坐标系选择
            //sb.Append("%ADD12R,0.050X0.050X*%\n");//画圆点
            sb.Append(string.Format("%ADD11C,{0}*%\n", numericUpDown_size.Value.ToString()));//画圆点
            sb.Append("\nG54D11*\n");//选择自定义光圈
            sb.Append("M02*\n");
            //保存到文件，使用gerberV加载，reload即可刷新视图
            StreamWriter sw = new StreamWriter(@"Auto-Generate-Gerber.gbx");
            sw.Write(sb.ToString());
            sw.Flush();
            sw.Close();
        }
    }
}
public class Placement
{
    private string symbol;
    private string x_pos;
    private string y_pos;
    private string rotation;

    public string Symbol { get => symbol; set => symbol = value; }
    public string X_pos { get => x_pos; set => x_pos = value; }
    public string Y_pos { get => y_pos; set => y_pos = value; }
    public string Rotation { get => rotation; set => rotation = value; }
}