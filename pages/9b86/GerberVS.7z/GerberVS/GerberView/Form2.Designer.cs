﻿
namespace GerberView
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_bom = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.openFileDialog_bom = new System.Windows.Forms.OpenFileDialog();
            this.openFileDialog_rep = new System.Windows.Forms.OpenFileDialog();
            this.label2 = new System.Windows.Forms.Label();
            this.tbx_bom = new System.Windows.Forms.TextBox();
            this.tbx_rep = new System.Windows.Forms.TextBox();
            this.btn_rep = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.numericUpDown_x = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_y = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label_first_smd = new System.Windows.Forms.Label();
            this.numericUpDown_pos_x = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown_pos_y = new System.Windows.Forms.NumericUpDown();
            this.Btn_Pos = new System.Windows.Forms.Button();
            this.numericUpDown_size = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.makedAsPlatedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cancelPlatedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label10 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_x)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_y)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_pos_x)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_pos_y)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_size)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Column1
            // 
            this.Column1.HeaderText = "序号";
            this.Column1.Name = "Column1";
            this.Column1.Width = 60;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "SCI代码";
            this.Column2.Name = "Column2";
            this.Column2.Width = 80;
            // 
            // Column3
            // 
            this.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Column3.DefaultCellStyle = dataGridViewCellStyle5;
            this.Column3.HeaderText = "料号";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.HeaderText = "名称";
            this.Column4.Name = "Column4";
            this.Column4.Width = 80;
            // 
            // Column5
            // 
            this.Column5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Column5.DefaultCellStyle = dataGridViewCellStyle6;
            this.Column5.HeaderText = "规格";
            this.Column5.Name = "Column5";
            // 
            // Column9
            // 
            this.Column9.HeaderText = "元件封装";
            this.Column9.Name = "Column9";
            // 
            // Column8
            // 
            this.Column8.HeaderText = "元件类别";
            this.Column8.Name = "Column8";
            // 
            // Column6
            // 
            this.Column6.HeaderText = "引脚数量";
            this.Column6.Name = "Column6";
            // 
            // Column7
            // 
            this.Column7.HeaderText = "使用机种";
            this.Column7.Name = "Column7";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToDeleteRows = false;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column10,
            this.Column11,
            this.Column12,
            this.Column13,
            this.Column14,
            this.Column15,
            this.Column16,
            this.Column17,
            this.Column18,
            this.Column19});
            this.dataGridView1.Location = new System.Drawing.Point(12, 106);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(1001, 332);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dataGridView1.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_CellMouseUp);
            // 
            // Column10
            // 
            this.Column10.HeaderText = "序号";
            this.Column10.Name = "Column10";
            this.Column10.Width = 60;
            // 
            // Column11
            // 
            this.Column11.HeaderText = "SCI代码";
            this.Column11.Name = "Column11";
            this.Column11.Width = 70;
            // 
            // Column12
            // 
            this.Column12.HeaderText = "料号";
            this.Column12.Name = "Column12";
            this.Column12.Width = 170;
            // 
            // Column13
            // 
            this.Column13.HeaderText = "名称";
            this.Column13.Name = "Column13";
            this.Column13.Width = 80;
            // 
            // Column14
            // 
            this.Column14.HeaderText = "规格";
            this.Column14.Name = "Column14";
            this.Column14.Width = 120;
            // 
            // Column15
            // 
            this.Column15.HeaderText = "型号";
            this.Column15.Name = "Column15";
            // 
            // Column16
            // 
            this.Column16.HeaderText = "数量";
            this.Column16.Name = "Column16";
            this.Column16.Width = 60;
            // 
            // Column17
            // 
            this.Column17.HeaderText = "位置";
            this.Column17.Name = "Column17";
            this.Column17.Width = 200;
            // 
            // Column18
            // 
            this.Column18.HeaderText = "供应商1";
            this.Column18.Name = "Column18";
            // 
            // Column19
            // 
            this.Column19.HeaderText = "供应商2";
            this.Column19.Name = "Column19";
            // 
            // btn_bom
            // 
            this.btn_bom.Location = new System.Drawing.Point(415, 14);
            this.btn_bom.Name = "btn_bom";
            this.btn_bom.Size = new System.Drawing.Size(75, 23);
            this.btn_bom.TabIndex = 1;
            this.btn_bom.Text = "Browser";
            this.btn_bom.UseVisualStyleBackColor = true;
            this.btn_bom.Click += new System.EventHandler(this.btn_bom_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "AE Bom：";
            // 
            // openFileDialog_bom
            // 
            this.openFileDialog_bom.FileName = "openFileDialog1";
            // 
            // openFileDialog_rep
            // 
            this.openFileDialog_rep.FileName = "openFileDialog2";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 12);
            this.label2.TabIndex = 3;
            this.label2.Text = "Placement：";
            // 
            // tbx_bom
            // 
            this.tbx_bom.Location = new System.Drawing.Point(79, 16);
            this.tbx_bom.Name = "tbx_bom";
            this.tbx_bom.Size = new System.Drawing.Size(318, 21);
            this.tbx_bom.TabIndex = 4;
            // 
            // tbx_rep
            // 
            this.tbx_rep.Location = new System.Drawing.Point(79, 42);
            this.tbx_rep.Name = "tbx_rep";
            this.tbx_rep.Size = new System.Drawing.Size(318, 21);
            this.tbx_rep.TabIndex = 5;
            // 
            // btn_rep
            // 
            this.btn_rep.Location = new System.Drawing.Point(415, 40);
            this.btn_rep.Name = "btn_rep";
            this.btn_rep.Size = new System.Drawing.Size(75, 23);
            this.btn_rep.TabIndex = 6;
            this.btn_rep.Text = "Browser";
            this.btn_rep.UseVisualStyleBackColor = true;
            this.btn_rep.Click += new System.EventHandler(this.btn_rep_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.richTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox1.Location = new System.Drawing.Point(736, 12);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(277, 86);
            this.richTextBox1.TabIndex = 7;
            this.richTextBox1.Text = "";
            // 
            // numericUpDown_x
            // 
            this.numericUpDown_x.Location = new System.Drawing.Point(124, 69);
            this.numericUpDown_x.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
            this.numericUpDown_x.Minimum = new decimal(new int[] {
            99999999,
            0,
            0,
            -2147483648});
            this.numericUpDown_x.Name = "numericUpDown_x";
            this.numericUpDown_x.Size = new System.Drawing.Size(109, 21);
            this.numericUpDown_x.TabIndex = 8;
            // 
            // numericUpDown_y
            // 
            this.numericUpDown_y.Location = new System.Drawing.Point(290, 69);
            this.numericUpDown_y.Maximum = new decimal(new int[] {
            -469762049,
            -590869294,
            5421010,
            0});
            this.numericUpDown_y.Minimum = new decimal(new int[] {
            -1304428545,
            434162106,
            542,
            -2147483648});
            this.numericUpDown_y.Name = "numericUpDown_y";
            this.numericUpDown_y.Size = new System.Drawing.Size(107, 21);
            this.numericUpDown_y.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 73);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 12);
            this.label3.TabIndex = 10;
            this.label3.Text = "Pos offset：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(95, 73);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(23, 12);
            this.label4.TabIndex = 11;
            this.label4.Text = "X：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(257, 73);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(23, 12);
            this.label5.TabIndex = 12;
            this.label5.Text = "Y：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(12, 91);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(305, 12);
            this.label6.TabIndex = 0;
            this.label6.Text = "注：以坐标文件里顶层第一个元件为MAKR点来计算偏移量";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(508, 71);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(23, 12);
            this.label8.TabIndex = 22;
            this.label8.Text = "Y：";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(508, 43);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(23, 12);
            this.label9.TabIndex = 21;
            this.label9.Text = "X：";
            // 
            // label_first_smd
            // 
            this.label_first_smd.AutoSize = true;
            this.label_first_smd.Location = new System.Drawing.Point(509, 17);
            this.label_first_smd.Name = "label_first_smd";
            this.label_first_smd.Size = new System.Drawing.Size(65, 12);
            this.label_first_smd.TabIndex = 20;
            this.label_first_smd.Text = "Mark Point";
            // 
            // numericUpDown_pos_x
            // 
            this.numericUpDown_pos_x.Location = new System.Drawing.Point(532, 41);
            this.numericUpDown_pos_x.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
            this.numericUpDown_pos_x.Minimum = new decimal(new int[] {
            99999999,
            0,
            0,
            -2147483648});
            this.numericUpDown_pos_x.Name = "numericUpDown_pos_x";
            this.numericUpDown_pos_x.Size = new System.Drawing.Size(97, 21);
            this.numericUpDown_pos_x.TabIndex = 26;
            // 
            // numericUpDown_pos_y
            // 
            this.numericUpDown_pos_y.Location = new System.Drawing.Point(532, 68);
            this.numericUpDown_pos_y.Maximum = new decimal(new int[] {
            -159383553,
            46653770,
            5421,
            0});
            this.numericUpDown_pos_y.Minimum = new decimal(new int[] {
            -469762049,
            -590869294,
            5421010,
            -2147483648});
            this.numericUpDown_pos_y.Name = "numericUpDown_pos_y";
            this.numericUpDown_pos_y.Size = new System.Drawing.Size(97, 21);
            this.numericUpDown_pos_y.TabIndex = 27;
            // 
            // Btn_Pos
            // 
            this.Btn_Pos.Enabled = false;
            this.Btn_Pos.Location = new System.Drawing.Point(415, 68);
            this.Btn_Pos.Name = "Btn_Pos";
            this.Btn_Pos.Size = new System.Drawing.Size(75, 23);
            this.Btn_Pos.TabIndex = 25;
            this.Btn_Pos.Text = "Calc";
            this.Btn_Pos.UseVisualStyleBackColor = true;
            this.Btn_Pos.Click += new System.EventHandler(this.Btn_Pos_Click);
            // 
            // numericUpDown_size
            // 
            this.numericUpDown_size.DecimalPlaces = 3;
            this.numericUpDown_size.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            this.numericUpDown_size.Location = new System.Drawing.Point(650, 67);
            this.numericUpDown_size.Name = "numericUpDown_size";
            this.numericUpDown_size.Size = new System.Drawing.Size(80, 21);
            this.numericUpDown_size.TabIndex = 28;
            this.numericUpDown_size.Value = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(650, 50);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 12);
            this.label7.TabIndex = 29;
            this.label7.Text = "Mark Size:";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.makedAsPlatedToolStripMenuItem,
            this.cancelPlatedToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(175, 48);
            // 
            // makedAsPlatedToolStripMenuItem
            // 
            this.makedAsPlatedToolStripMenuItem.Name = "makedAsPlatedToolStripMenuItem";
            this.makedAsPlatedToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.makedAsPlatedToolStripMenuItem.Text = "Maked as Plated";
            this.makedAsPlatedToolStripMenuItem.Click += new System.EventHandler(this.makedAsPlatedToolStripMenuItem_Click);
            // 
            // cancelPlatedToolStripMenuItem
            // 
            this.cancelPlatedToolStripMenuItem.Name = "cancelPlatedToolStripMenuItem";
            this.cancelPlatedToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.cancelPlatedToolStripMenuItem.Text = "Cancel Plated";
            this.cancelPlatedToolStripMenuItem.Click += new System.EventHandler(this.cancelPlatedToolStripMenuItem_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label10.Location = new System.Drawing.Point(509, 92);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(197, 12);
            this.label10.TabIndex = 30;
            this.label10.Text = "贴完的元件可以右键标记为绿色背景";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1016, 450);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.numericUpDown_size);
            this.Controls.Add(this.numericUpDown_pos_y);
            this.Controls.Add(this.numericUpDown_pos_x);
            this.Controls.Add(this.Btn_Pos);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label_first_smd);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.numericUpDown_y);
            this.Controls.Add(this.numericUpDown_x);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.btn_rep);
            this.Controls.Add(this.tbx_rep);
            this.Controls.Add(this.tbx_bom);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_bom);
            this.Controls.Add(this.dataGridView1);
            this.DoubleBuffered = true;
            this.Name = "Form2";
            this.Text = "Form2";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form2_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_x)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_y)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_pos_x)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_pos_y)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_size)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btn_bom;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.OpenFileDialog openFileDialog_bom;
        private System.Windows.Forms.OpenFileDialog openFileDialog_rep;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbx_bom;
        private System.Windows.Forms.TextBox tbx_rep;
        private System.Windows.Forms.Button btn_rep;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.NumericUpDown numericUpDown_x;
        private System.Windows.Forms.NumericUpDown numericUpDown_y;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button Btn_Pos;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label_first_smd;
        private System.Windows.Forms.NumericUpDown numericUpDown_pos_x;
        private System.Windows.Forms.NumericUpDown numericUpDown_pos_y;
        private System.Windows.Forms.NumericUpDown numericUpDown_size;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem makedAsPlatedToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cancelPlatedToolStripMenuItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column18;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column19;
        private System.Windows.Forms.Label label10;
    }
}